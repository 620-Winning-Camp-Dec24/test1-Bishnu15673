export interface Certificate {
  id: string;
  studentName: string;
  institution: string;
  course: string;
  issueDate: string;
  certificateHash: string;
  status: 'verified' | 'pending' | 'invalid';
}

export interface VerificationResult {
  isValid: boolean;
  message: string;
  certificate?: Certificate;
}