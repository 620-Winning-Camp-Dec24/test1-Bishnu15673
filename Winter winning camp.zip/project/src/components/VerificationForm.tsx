import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface Props {
  onVerify: (hash: string) => void;
}

export function VerificationForm({ onVerify }: Props) {
  const [certificateHash, setCertificateHash] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (certificateHash.trim()) {
      onVerify(certificateHash);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md">
      <div className="relative">
        <input
          type="text"
          value={certificateHash}
          onChange={(e) => setCertificateHash(e.target.value)}
          placeholder="Enter certificate hash"
          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
        />
        <button
          type="submit"
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Search className="w-5 h-5" />
        </button>
      </div>
    </form>
  );
}