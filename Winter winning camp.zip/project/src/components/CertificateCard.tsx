import React from 'react';
import { Shield, CheckCircle, XCircle, Clock } from 'lucide-react';
import type { Certificate } from '../types';

interface Props {
  certificate: Certificate;
}

export function CertificateCard({ certificate }: Props) {
  const getStatusIcon = () => {
    switch (certificate.status) {
      case 'verified':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'invalid':
        return <XCircle className="w-6 h-6 text-red-500" />;
      default:
        return <Clock className="w-6 h-6 text-yellow-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-md">
      <div className="flex items-center justify-between mb-4">
        <Shield className="w-8 h-8 text-blue-600" />
        {getStatusIcon()}
      </div>
      
      <h3 className="text-xl font-bold text-gray-800 mb-2">{certificate.studentName}</h3>
      
      <div className="space-y-2 text-gray-600">
        <p><span className="font-semibold">Institution:</span> {certificate.institution}</p>
        <p><span className="font-semibold">Course:</span> {certificate.course}</p>
        <p><span className="font-semibold">Issue Date:</span> {certificate.issueDate}</p>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <p className="text-sm font-mono break-all">
          <span className="font-semibold">Certificate Hash:</span>
          <br />
          {certificate.certificateHash}
        </p>
      </div>
    </div>
  );
}