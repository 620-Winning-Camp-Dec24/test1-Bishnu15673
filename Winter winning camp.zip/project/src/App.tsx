import React, { useState } from 'react';
import { Shield, GraduationCap } from 'lucide-react';
import { CertificateCard } from './components/CertificateCard';
import { VerificationForm } from './components/VerificationForm';
import type { Certificate, VerificationResult } from './types';

// Simulated verification process
const mockVerify = async (hash: string): Promise<VerificationResult> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock certificate data
  if (hash === '0x123') {
    return {
      isValid: true,
      message: 'Certificate verified successfully',
      certificate: {
        id: '1',
        studentName: 'John Doe',
        institution: 'Tech University',
        course: 'Computer Science',
        issueDate: '2024-03-15',
        certificateHash: '0x123',
        status: 'verified'
      }
    };
  }
  
  return {
    isValid: false,
    message: 'Invalid certificate hash'
  };
};

function App() {
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleVerify = async (hash: string) => {
    setIsLoading(true);
    try {
      const result = await mockVerify(hash);
      setVerificationResult(result);
    } catch (error) {
      setVerificationResult({
        isValid: false,
        message: 'Verification failed. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">CertChain</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <GraduationCap className="w-16 h-16 text-blue-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Blockchain Certificate Verification
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Verify the authenticity of educational certificates using blockchain technology.
            Enter the certificate hash below to begin verification.
          </p>
        </div>

        {/* Verification Form */}
        <div className="flex justify-center mb-8">
          <VerificationForm onVerify={handleVerify} />
        </div>

        {/* Results */}
        <div className="flex justify-center">
          {isLoading ? (
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Verifying certificate...</p>
            </div>
          ) : verificationResult && (
            <div className="text-center">
              {verificationResult.isValid ? (
                <div className="space-y-4">
                  <div className="text-green-600 font-semibold">
                    {verificationResult.message}
                  </div>
                  {verificationResult.certificate && (
                    <CertificateCard certificate={verificationResult.certificate} />
                  )}
                </div>
              ) : (
                <div className="text-red-600 font-semibold">
                  {verificationResult.message}
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;